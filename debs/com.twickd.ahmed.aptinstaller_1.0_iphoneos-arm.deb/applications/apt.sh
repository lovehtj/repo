#!/bash

apt install git 
apt install sileoprep
apt install sileo      
mkdir /var/mobile/bash/
cd /var/mobile/bash/ 
mkdir aptinstaller
cd aptinstaller
git clone --recursive https://github.com/demhademha/sileo-apt-.git  

unzip /var/mobile/bash/aptinstaller/sileo-apt-/SileoSupport.zip
cd /usr/bin

mv apt-get apt-get-real

cp /var/mobile/bash/aptinstaller/apt-get /usr/bin
cd /usr/bin
 chmod 755 apt-get
dpkg -i /var/mobile/bash/aptinstaller/us.diatr.sileorespring_1.1_iphoneos-arm.deb

killall SpringBoard

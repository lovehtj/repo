(function() {
    // Load the script
    var script = document.createElement("SCRIPT");
    script.src = 'https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js';
    script.type = 'text/javascript';
    script.onload = function() {
		var $ = window.jQuery;
        $('input,div,p,span,cite,h1,h2,h4,h5,b,a,fbar').css('color','#969696');
    };
    document.getElementsByTagName("head")[0].appendChild(script);
})();

var elems = document.querySelectorAll("*"),
    oldColor = "rgb(255, 255, 255)",
    newColor = "rgb(30, 30, 30)";
    
function getValue (elem, property) {
    return window.getComputedStyle(elem, null)
        .getPropertyValue(property);
}

Array.prototype.forEach.call(elems, function (elem) {
    var backgroundColor = getValue(elem, "background-color"),
        borderColor = getValue(elem, "border-color");


    if (backgroundColor == oldColor) {
        elem.style.backgroundColor = newColor;
    }

    if (borderColor == oldColor) {
        elem.style.borderColor = newColor;
    }
});